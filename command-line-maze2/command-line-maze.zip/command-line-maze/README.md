# Yunchae Cho's Command Line Maze 

## Instructions: 
1. Use 'cd <directory>' on your terminal to navigate through directories.
2. Use 'ls' to list files. 
3. Start navigating by going into the 'entrance' directory. 
4. Look for clues for the password stored in text files to find your way out! 